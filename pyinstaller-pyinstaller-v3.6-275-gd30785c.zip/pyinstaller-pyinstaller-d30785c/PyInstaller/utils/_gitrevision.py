#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "d30785c9a4"     # abbreviated commit hash
commit = "d30785c9a46493fc84cd68fa29d1743219e95019"  # commit hash
date = "2020-07-17 17:33:32 +1000"   # commit date
author = "Rok Mandeljc <rok.mandeljc@gmail.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """hooks: GLib: bundle the spawn helper executables on Windows (#5000)

On Windows, GLib needs a spawn helper (gspawn-winXX-helper.exe and
gspawn-winXX-helper-console.exe for non-console and console
version, respectively) for g_spawn* API.

Failing to bundle this helper prevents GLib from launching external
programs (e.g., opening a web browser when user clicks on a web-site
link in a GtkAboutDialog)."""

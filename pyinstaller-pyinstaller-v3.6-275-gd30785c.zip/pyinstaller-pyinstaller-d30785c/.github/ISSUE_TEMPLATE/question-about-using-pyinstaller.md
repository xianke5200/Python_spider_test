---
name: Question about using PyInstaller
about: This is not the appropriate channel
title: ''
labels: kind:support
assignees: ''

---

Please use the mailing list see <http://www.pyinstaller.org/support.html#mailing-list> for details.

Posts that are not a bug report or a feature/enhancement request will not be addressed on this issue tracker, but closed.
